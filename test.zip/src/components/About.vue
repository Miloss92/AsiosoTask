<template>
    <div class="about-component">
        <h1>About us:</h1>
        <p>
            NBC News Digital is a collection of innovative and powerful news brands that deliver compelling, diverse and visually engaging stories on your platform of choice. NBC News Digital features world-class brands including NBCNews.com, MSNBC.com, TODAY.com, Nightly News, Meet the Press, Dateline, and the existing apps and digital extensions of these respective properties. We provide something for every news consumer with our comprehensive offerings that deliver the best in breaking news, segments from your favorite NBC News shows, live video coverage, original journalism, lifestyle features, commentary and local updates.</p>
        <p>
            NBC News is pleased to offer closed captioning on long-form content and certain other content that it makes available on television and online via websites and apps on mobile devices. To report an issue or concern regarding closed captioning on NBC News programs viewed on television or online, please contact us at affiliate.operations@nbcuni.com or 1-866-787-6228.
            To assist us in resolving the issue, please provide the following information when you contact us for assistance with captions:
            Your name, address, telephone number and email address
            Your preferred method of contact (phone or email)
            The name of the program with the captioning issue
        </p>
        <p>
            A brief description of the captioning issue, including the date and time you experienced the problem
            If you are watching on television, please provide the name of your pay TV provider
            If you are watching online, please identify the device and brand (e.g., computer, tablet, smartphone) and software (including version) you are using
            If you wish to submit a written complaint, please send it to:
        </p>
        <p>
            A brief description of the captioning issue, including the date and time you experienced the problem
            If you are watching on television, please provide the name of your pay TV provider
        </p>
        <p>
             Margaret TobeyVice President, Regulatory Affairs, NBCUniversal300 New Jersey Avenue, NW Suite 700Washington, DC 20001.  NBC News is pleased to offer closed captioning on long-form content and certain other content that it makes available on television and online via websites and apps on mobile devices. To report an issue or concern regarding closed captioning on NBC News programs viewed on television or online, please contact us at affiliate.operations@nbcuni.com or 1-866-787-6228.
        </p>
        <p>
            NBC News is part of the NBCUniversal News Group, a division of NBCUniversal, which is owned by Comcast Corporation. For more information about NBCUniversal, please visit www.NBCUniversal.com.
        </p>
    </div>
</template>

<script>
    export default {
        name: "AboutComponent",
    }
    
</script>

<style scoped>
    .about-component {
        width: 1055px;
        height: 1200px;
    }
    p {
        font-size: 25px;
    }
</style>